from django.contrib import admin
from .models import Course, Quest, QuestProgress


class QuestInline(admin.TabularInline):
    model = Quest
    extra = 0
    fields = ['title', 'slug', 'order', 'difficulty', 'xp_reward', 'is_published']


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['icon', 'title', 'tier', 'is_free', 'quest_count', 'order', 'is_published']
    list_filter = ['tier', 'is_free', 'is_published']
    prepopulated_fields = {'slug': ('title',)}
    inlines = [QuestInline]
    search_fields = ['title']


@admin.register(Quest)
class QuestAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'difficulty', 'xp_reward', 'order', 'is_published']
    list_filter = ['course', 'difficulty', 'is_published']
    prepopulated_fields = {'slug': ('title',)}
    search_fields = ['title']


@admin.register(QuestProgress)
class QuestProgressAdmin(admin.ModelAdmin):
    list_display = ['user', 'quest', 'is_completed', 'attempts', 'completed_at']
    list_filter = ['is_completed', 'completed_at']
    search_fields = ['user__username', 'quest__title']