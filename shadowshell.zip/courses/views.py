from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Course, Quest, QuestProgress


@login_required
def course_list_view(request):
    courses = Course.objects.filter(is_published=True).order_by('order')
    profile = request.user.cyber_profile

    course_data = []
    for course in courses:
        total = course.quests.filter(is_published=True).count()
        completed = QuestProgress.objects.filter(
            user=request.user,
            quest__course=course,
            is_completed=True,
        ).count()
        percent = round((completed / total) * 100) if total > 0 else 0

        locked = course.requires_premium and not profile.is_premium_active

        course_data.append({
            'course': course,
            'total': total,
            'completed': completed,
            'percent': percent,
            'locked': locked,
        })

    return render(request, 'courses/course_list.html', {
        'course_data': course_data,
        'profile': profile,
    })


@login_required
def course_detail_view(request, slug):
    course = get_object_or_404(Course, slug=slug, is_published=True)
    profile = request.user.cyber_profile

    if course.requires_premium and not profile.is_premium_active:
        messages.warning(request, '🔒 Bu kurs Premium obuna talab qiladi!')
        return redirect('billing:pricing')

    quests = course.quests.filter(is_published=True).order_by('order')

    quest_data = []
    for quest in quests:
        progress = QuestProgress.objects.filter(
            user=request.user, quest=quest
        ).first()
        quest_data.append({
            'quest': quest,
            'progress': progress,
            'is_completed': progress.is_completed if progress else False,
        })

    return render(request, 'courses/course_detail.html', {
        'course': course,
        'quest_data': quest_data,
        'profile': profile,
    })


@login_required
def quest_detail_view(request, course_slug, quest_slug):
    course = get_object_or_404(Course, slug=course_slug, is_published=True)
    quest = get_object_or_404(Quest, slug=quest_slug, course=course, is_published=True)
    profile = request.user.cyber_profile

    if course.requires_premium and not profile.is_premium_active:
        messages.warning(request, '🔒 Bu topshiriq Premium obuna talab qiladi!')
        return redirect('billing:pricing')

    progress, created = QuestProgress.objects.get_or_create(
        user=request.user, quest=quest
    )

    # Keyingi va oldingi topshiriqlar
    next_quest = Quest.objects.filter(
        course=course, order__gt=quest.order, is_published=True
    ).order_by('order').first()

    prev_quest = Quest.objects.filter(
        course=course, order__lt=quest.order, is_published=True
    ).order_by('-order').first()

    return render(request, 'courses/quest_detail.html', {
        'course': course,
        'quest': quest,
        'progress': progress,
        'next_quest': next_quest,
        'prev_quest': prev_quest,
        'profile': profile,
    })